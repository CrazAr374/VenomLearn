"""VenomLearn - Interactive Python Learning Package

A fun, engaging, and accessible way to learn Python programming
through interactive terminal-based lessons and exercises.
"""

__version__ = '0.1.0'