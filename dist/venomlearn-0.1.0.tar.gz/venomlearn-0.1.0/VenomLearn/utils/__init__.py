"""Utility modules for VenomLearn learning package.

This package contains utility modules for terminal UI, progress tracking, and code checking.
"""