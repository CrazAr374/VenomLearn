"""Utility modules for BytebyByte learning package.

This package contains utility modules for terminal UI, progress tracking, and code checking.
"""