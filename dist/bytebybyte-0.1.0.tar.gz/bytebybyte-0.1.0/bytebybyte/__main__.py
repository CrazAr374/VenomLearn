"""Main entry point for running bytebybyte as a module.

This file allows the package to be executed directly using:
python -m bytebybyte
"""

from bytebybyte.main import main

if __name__ == "__main__":
    main()