"""Topics module for BytebyByte learning package.

This module contains all the learning topics from beginner to advanced levels.
"""